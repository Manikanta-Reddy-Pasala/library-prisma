#!/usr/bin/env python3

# Simple test to check if the app works
try:
    from app import create_app
    app = create_app()
    
    print("✅ App created successfully")
    print(f"✅ Blueprints registered: {list(app.blueprints.keys())}")
    
    # Test a simple route
    with app.test_client() as client:
        response = client.get('/')
        print(f"✅ Home page status: {response.status_code}")
        
        response = client.get('/wizard/general')
        print(f"✅ General settings page status: {response.status_code}")
        
    print("✅ All tests passed!")
    
except Exception as e:
    print(f"❌ Error: {e}")
    import traceback
    traceback.print_exc()