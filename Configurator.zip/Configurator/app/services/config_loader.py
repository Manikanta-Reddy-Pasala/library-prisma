import zipfile
import configparser
import tempfile
import os
from typing import Dict, Any
from app.models.configuration import Configuration, GeneralSettings, BTSPAConfig, ComponentSettings, CertificateConfig, InterceptionServiceConfig
from app.models.configuration import PAConfiguration, CoreNetworkConfig, SubsystemConfig, ScannerConfig, AntennaConfig, AntennaServiceConfig
from app.models.configuration import CACertConfig, MikrotikConfig, MercuryCredentials, AttenuationTable

class ConfigLoader:
    def __init__(self):
        pass
    
    def load_from_zip(self, zip_path: str) -> Configuration:
        """Extract and parse configuration from ZIP file"""
        print(f"DEBUG: Loading configuration from ZIP: {zip_path}")
        with tempfile.TemporaryDirectory() as temp_dir:
            print(f"DEBUG: Using temp directory: {temp_dir}")
            # Extract ZIP file
            with zipfile.ZipFile(zip_path, 'r') as zip_ref:
                zip_ref.extractall(temp_dir)
                print(f"DEBUG: Extracted files: {os.listdir(temp_dir)}")
            
            # Find ui.ini file
            ui_ini_path = os.path.join(temp_dir, 'ui.ini')
            if not os.path.exists(ui_ini_path):
                raise ValueError("ui.ini file not found in ZIP package")
            
            print(f"DEBUG: Found ui.ini at: {ui_ini_path}")
            
            # Parse ui.ini to get field mappings and optional form values
            try:
                parsed_ini = self.parse_full_ui_ini(ui_ini_path)
                field_mappings = parsed_ini.get('field_mappings', {})
                form_values = parsed_ini.get('form_values', {})
                print(f"DEBUG: Parsed {len(field_mappings)} field mappings and {len(form_values)} form values")
            except Exception as e:
                print(f"DEBUG: Error parsing ui.ini: {e}")
                raise
            
            # Find and extract configuration files from the package (also handle embedded tar.gz)
            config_files = self._extract_config_files(temp_dir)
            if not config_files:
                # Try to extract tar.gz inside the zip
                for name in os.listdir(temp_dir):
                    if name.endswith('.tar.gz'):
                        import tarfile
                        tar_path = os.path.join(temp_dir, name)
                        with tarfile.open(tar_path, 'r:gz') as tar:
                            tar.extractall(os.path.join(temp_dir, 'pkg'))
                        config_files = self._extract_config_files(os.path.join(temp_dir, 'pkg'))
                        break
            
            # Extract configuration values based on mappings
            config = self.extract_config_values(config_files, field_mappings)
            
            # If form_values present, overlay them directly for completeness
            if form_values:
                self.apply_form_values(config, form_values)
            
            return config
    
    def parse_ui_ini(self, ini_path: str) -> Dict[str, str]:
        """Deprecated: kept for compatibility. Use parse_full_ui_ini instead."""
        data = self.parse_full_ui_ini(ini_path)
        return data.get('field_mappings', {})

    def parse_full_ui_ini(self, ini_path: str) -> Dict[str, Dict[str, str]]:
        """Parse ui.ini returning both field mappings and form values if present"""
        print(f"DEBUG: Parsing ui.ini file: {ini_path}")
        try:
            with open(ini_path, 'r') as f:
                content = f.read()
                print(f"DEBUG: ui.ini content length: {len(content)}")
                print(f"DEBUG: First 500 chars of ui.ini:")
                print(content[:500])
                print(f"DEBUG: Last 500 chars of ui.ini:")
                print(content[-500:])
        except Exception as e:
            print(f"DEBUG: Error reading ui.ini file: {e}")
        
        parser = configparser.ConfigParser()
        try:
            parser.read(ini_path)
            print(f"DEBUG: ConfigParser sections: {parser.sections()}")
        except Exception as e:
            print(f"DEBUG: Error parsing ui.ini with ConfigParser: {e}")
            print(f"DEBUG: Error type: {type(e)}")
            import traceback
            traceback.print_exc()
            raise
        
        result: Dict[str, Dict[str, str]] = {}
        if 'field_mappings' in parser:
            result['field_mappings'] = dict(parser['field_mappings'])
            print(f"DEBUG: Found {len(result['field_mappings'])} field mappings")
        if 'form_values' in parser:
            try:
                result['form_values'] = dict(parser['form_values'])
                print(f"DEBUG: Found {len(result['form_values'])} form values")
            except Exception as e:
                print(f"DEBUG: Error accessing form_values section: {e}")
                print(f"DEBUG: Error type: {type(e)}")
                import traceback
                traceback.print_exc()
                # Try to read the raw content to see the problematic line
                try:
                    with open(ini_path, 'r') as f:
                        lines = f.readlines()
                        for i, line in enumerate(lines):
                            if line.strip().startswith('general_settings.attenuation_tables'):
                                print(f"DEBUG: Problematic line {i+1}: {repr(line)}")
                                # Remove the problematic line entirely
                                print(f"DEBUG: Removing problematic attenuation_tables line")
                                fixed_lines = []
                                for j, l in enumerate(lines):
                                    if not (j == i and 'attenuation_tables' in l):
                                        fixed_lines.append(l)
                                
                                # Write the fixed content back
                                with open(ini_path, 'w') as f:
                                    f.writelines(fixed_lines)
                                print(f"DEBUG: Fixed ui.ini file, retrying parse")
                                
                                # Retry parsing
                                parser = configparser.ConfigParser()
                                parser.read(ini_path)
                                result['form_values'] = dict(parser['form_values'])
                                print(f"DEBUG: Successfully parsed form_values after fix")
                                return result
                                break
                except Exception as read_error:
                    print(f"DEBUG: Could not read file to find problematic line: {read_error}")
                raise
        return result
    
    def _extract_config_files(self, temp_dir: str) -> Dict[str, str]:
        """Extract configuration files from the extracted package"""
        config_files = {}
        
        # Look for package files (tar.gz or extracted directory)
        for root, dirs, files in os.walk(temp_dir):
            for file in files:
                if file.endswith('.conf'):
                    file_path = os.path.join(root, file)
                    # Get relative path from opt/config/
                    rel_path = os.path.relpath(file_path, temp_dir)
                    
                    # Remove package directory prefix if present
                    path_parts = rel_path.split(os.sep)
                    if 'opt' in path_parts and 'config' in path_parts:
                        opt_index = path_parts.index('opt')
                        config_index = path_parts.index('config')
                        if config_index == opt_index + 1:
                            rel_path = os.sep.join(path_parts[config_index + 1:])
                    
                    with open(file_path, 'r') as f:
                        config_files[rel_path] = f.read()
        
        return config_files
    
    def extract_config_values(self, config_files: Dict[str, str], field_mappings: Dict[str, str]) -> Configuration:
        """Extract values from config files based on mappings"""
        config = Configuration()
        
        # Parse all config files
        parsed_configs = {}
        for file_path, content in config_files.items():
            try:
                parser = configparser.ConfigParser()
                parser.read_string(content)
                parsed_configs[file_path] = parser
            except Exception as e:
                print(f"Warning: Could not parse {file_path}: {str(e)}")
                continue
        
        # Extract values based on field mappings
        for field_path, file_location in field_mappings.items():
            try:
                value = self._extract_field_value(parsed_configs, file_location)
                if value is not None:
                    self._set_config_field(config, field_path, value)
            except Exception as e:
                print(f"Warning: Could not extract {field_path}: {str(e)}")
                continue
        
        return config
    
    def _extract_field_value(self, parsed_configs: Dict[str, configparser.ConfigParser], file_location: str):
        """Extract a specific field value from parsed config files"""
        # Parse file_location format: "file_path:section.key"
        if ':' not in file_location:
            return None
        
        file_path, section_key = file_location.split(':', 1)
        
        if file_path not in parsed_configs:
            return None
        
        config_parser = parsed_configs[file_path]
        
        if '.' not in section_key:
            return None
        
        section, key = section_key.split('.', 1)
        
        if section not in config_parser:
            return None
        
        return config_parser[section].get(key)
    
    def _set_config_field(self, config: Configuration, field_path: str, value: str):
        """Set a configuration field based on the field path"""
        path_parts = field_path.split('.')
        
        if len(path_parts) < 2:
            return
        
        section = path_parts[0]
        field = '.'.join(path_parts[1:])
        
        # Convert string values to appropriate types
        converted_value = self._convert_value(value)
        
        if section == 'general_settings':
            self._set_general_settings_field(config.general_settings, field, converted_value)
        elif section == 'bts_pa_config':
            self._set_bts_pa_field(config.bts_pa_config, field, converted_value)
        elif section == 'component_settings':
            self._set_component_settings_field(config.component_settings, field, converted_value)
        elif section == 'certificate_config':
            self._set_certificate_config_field(config.certificate_config, field, converted_value)
        elif section == 'interception_service':
            self._set_interception_service_field(config.interception_service, field, converted_value)

    def apply_form_values(self, config: Configuration, form_values: Dict[str, str]):
        """Apply flattened form values directly to the Configuration object"""
        for field_path, raw_value in form_values.items():
            # Attempt conversion using same rules
            converted_value = self._convert_value(raw_value)
            try:
                self._set_config_field(config, field_path, converted_value)
            except Exception:
                continue
    
    def _convert_value(self, value: str):
        """Convert string value to appropriate type"""
        if value is None:
            return None
        
        # Handle boolean values
        if value.lower() in ['true', 'false']:
            return value.lower() == 'true'
        
        # Handle comma-separated lists (e.g., channel selections)
        if ',' in value:
            parts = [p.strip() for p in value.split(',') if p.strip() != '']
            if parts:
                # If all parts are integers, return list[int]
                if all(p.isdigit() for p in parts):
                    return [int(p) for p in parts]
                return parts
        
        # Handle numeric values
        try:
            if '.' in value:
                return float(value)
            else:
                return int(value)
        except ValueError:
            pass
        
        # Return as string (unescape %% back to %)
        return value.replace('%%', '%') if isinstance(value, str) else value
    
    def _set_general_settings_field(self, general_settings: GeneralSettings, field: str, value):
        """Set general settings field"""
        # Special handling for attenuation_tables
        if field == 'attenuation_tables.name':
            if not general_settings.attenuation_tables:
                general_settings.attenuation_tables = [{'name': value, 'value': '0.0B / 0.00%'}]
            else:
                general_settings.attenuation_tables[0]['name'] = value
        elif field == 'attenuation_tables.value':
            if not general_settings.attenuation_tables:
                general_settings.attenuation_tables = [{'name': 'Attenuation Table', 'value': value}]
            else:
                general_settings.attenuation_tables[0]['value'] = value
        elif hasattr(general_settings, field):
            setattr(general_settings, field, value)
    
    def _set_bts_pa_field(self, bts_pa_config: BTSPAConfig, field: str, value):
        """Set BTS PA configuration field"""
        # Support nested paths like "pa1.available" or "pa1.selected_channels"
        if field.startswith('pa'):
            parts = field.split('.')
            pa_key = parts[0]  # pa1, pa2, ...
            pa_config = getattr(bts_pa_config, pa_key, None)
            if pa_config is None:
                return
            if len(parts) == 1:
                # Setting entire pa object not supported; ignore
                return
            subfield = parts[1]
            if subfield == 'available':
                pa_config.available = value
            elif subfield == 'selected_channels':
                if isinstance(value, str):
                    # Fallback parse if not already converted
                    items = [v.strip() for v in value.split(',') if v.strip()]
                    try:
                        value = [int(v) for v in items]
                    except Exception:
                        value = items
                setattr(pa_config, 'selected_channels', value)
        elif hasattr(bts_pa_config, field):
            setattr(bts_pa_config, field, value)
    
    def _set_component_settings_field(self, component_settings: ComponentSettings, field: str, value):
        """Set component settings field"""
        field_parts = field.split('.')
        if len(field_parts) >= 2:
            subsection = field_parts[0]
            subfield = '.'.join(field_parts[1:])
            
            if hasattr(component_settings, subsection):
                subsection_obj = getattr(component_settings, subsection)
                if hasattr(subsection_obj, subfield):
                    setattr(subsection_obj, subfield, value)
    
    def _set_certificate_config_field(self, certificate_config: CertificateConfig, field: str, value):
        """Set certificate configuration field"""
        field_parts = field.split('.')
        if len(field_parts) >= 2:
            subsection = field_parts[0]
            subfield = '.'.join(field_parts[1:])
            
            if hasattr(certificate_config, subsection):
                subsection_obj = getattr(certificate_config, subsection)
                if hasattr(subsection_obj, subfield):
                    setattr(subsection_obj, subfield, value)
    
    def _set_interception_service_field(self, interception_service: InterceptionServiceConfig, field: str, value):
        """Set interception service field"""
        if hasattr(interception_service, field):
            setattr(interception_service, field, value)