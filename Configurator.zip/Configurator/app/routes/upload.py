from flask import Blueprint, request, session, redirect, url_for, flash, render_template
from werkzeug.utils import secure_filename
from app.services.config_loader import ConfigLoader
import os
import tempfile

upload_bp = Blueprint('upload', __name__)

ALLOWED_EXTENSIONS = {'zip'}

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@upload_bp.route('/upload', methods=['GET', 'POST'])
def upload_config():
    """Upload and parse existing configuration"""
    if request.method == 'POST':
        # Check if file was uploaded
        if 'config_file' not in request.files:
            flash('No file selected', 'error')
            return redirect(request.url)
        
        file = request.files['config_file']
        
        if file.filename == '':
            flash('No file selected', 'error')
            return redirect(request.url)
        
        if file and allowed_file(file.filename):
            try:
                # Save uploaded file temporarily
                filename = secure_filename(file.filename)
                
                with tempfile.NamedTemporaryFile(delete=False, suffix='.zip') as temp_file:
                    file.save(temp_file.name)
                    temp_path = temp_file.name
                
                # Load configuration from ZIP file
                config_loader = ConfigLoader()
                config = config_loader.load_from_zip(temp_path)
                
                # Clean up temporary file
                os.unlink(temp_path)
                
                # Save configuration to session
                session['configuration'] = config.to_dict()
                session['wizard_step'] = 'general'
                session['edit_mode'] = True
                
                flash(f'Configuration loaded successfully from {filename}', 'success')
                return redirect(url_for('wizard.wizard_step', step='general'))
                
            except Exception as e:
                # Clean up temporary file if it exists
                if 'temp_path' in locals() and os.path.exists(temp_path):
                    os.unlink(temp_path)
                
                flash(f'Error loading configuration: {str(e)}', 'error')
                return redirect(request.url)
        else:
            flash('Invalid file type. Please upload a ZIP file.', 'error')
            return redirect(request.url)
    
    return render_template('upload/upload.html')

@upload_bp.route('/upload-page')
def upload_page():
    """Show upload page"""
    return render_template('upload/upload.html')