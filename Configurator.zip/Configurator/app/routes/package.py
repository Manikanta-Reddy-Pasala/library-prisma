from flask import Blueprint, session, redirect, url_for, send_file, flash, render_template, current_app
from app.models.configuration import Configuration
from app.services.package_service import PackageService
from app.utils.file_utils import FileUtils
import os
import atexit
import threading
import time

package_bp = Blueprint('package', __name__)

# Cleanup thread for old files
def cleanup_worker():
    """Background worker to clean up old files"""
    while True:
        try:
            # Use absolute directories from app config when available
            try:
                packages_dir = current_app.config.get('GENERATED_PACKAGES_DIR', 'generated_packages')
                uploads_dir = current_app.config.get('UPLOAD_FOLDER', 'uploads')
                temp_dir = current_app.config.get('TEMP_DIR', 'temp')
            except Exception:
                packages_dir = 'generated_packages'
                uploads_dir = 'uploads'
                temp_dir = 'temp'

            FileUtils.cleanup_old_files(packages_dir, max_age_hours=24)
            FileUtils.cleanup_old_files(uploads_dir, max_age_hours=2)
            FileUtils.cleanup_old_files(temp_dir, max_age_hours=1)
        except Exception as e:
            print(f"Cleanup error: {str(e)}")
        
        # Sleep for 1 hour
        time.sleep(3600)

# Start cleanup thread
cleanup_thread = threading.Thread(target=cleanup_worker, daemon=True)
cleanup_thread.start()

@package_bp.route('/generate', methods=['GET', 'POST'])
def generate():
    """Generate and download configuration package"""
    if 'configuration' not in session:
        flash('No configuration found. Please complete the wizard first.', 'error')
        return redirect(url_for('wizard.index'))
    
    try:
        # Load configuration from session
        config = Configuration()
        config.from_dict(session['configuration'])
        
        # Validate configuration
        errors = config.validate()
        if errors:
            flash('Configuration validation failed. Please check your inputs.', 'error')
            return redirect(url_for('wizard.wizard_step', step='general'))
        
        # Generate package
        package_service = PackageService()
        
        try:
            # Create Debian package
            print(f"Creating Debian package for {config.general_settings.system_name}")
            deb_path = package_service.create_debian_package(config)
            print(f"Debian package created: {deb_path}")
            
            # Create ui.ini content
            ui_ini_content = package_service.create_ui_ini(config)
            print("UI.ini content created")
            
            # Create ZIP package with both files
            zip_path = package_service.create_zip_package(deb_path, ui_ini_content, config)
            print(f"ZIP package created: {zip_path}")
            
        except Exception as e:
            print(f"Package generation error: {str(e)}")
            import traceback
            traceback.print_exc()
            raise
        
        # Store package info in session for download
        session['generated_package'] = {
            'zip_path': zip_path,
            'deb_path': deb_path,
            'system_name': config.general_settings.system_name
        }
        
        return render_template('package/generated.html', 
                             config=config,
                             zip_filename=os.path.basename(zip_path))
        
    except Exception as e:
        flash(f'Error generating package: {str(e)}', 'error')
        return redirect(url_for('wizard.wizard_step', step='interception'))

@package_bp.route('/download')
def download():
    """Download the generated package"""
    if 'generated_package' not in session:
        flash('No package available for download.', 'error')
        return redirect(url_for('wizard.index'))
    
    package_info = session['generated_package']
    zip_path = package_info['zip_path']
    
    if not os.path.exists(zip_path):
        flash('Package file not found.', 'error')
        return redirect(url_for('wizard.index'))
    
    return send_file(zip_path, 
                     as_attachment=True, 
                     download_name=os.path.basename(zip_path),
                     mimetype='application/zip')

@package_bp.route('/review')
def review():
    """Review configuration before generating package"""
    if 'configuration' not in session:
        flash('No configuration found. Please complete the wizard first.', 'error')
        return redirect(url_for('wizard.index'))
    
    config = Configuration()
    config.from_dict(session['configuration'])
    
    return render_template('package/review.html', config=config)