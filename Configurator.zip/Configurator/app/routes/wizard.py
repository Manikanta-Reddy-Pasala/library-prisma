from flask import Blueprint, render_template, request, session, redirect, url_for, flash
from app.models.configuration import Configuration
import uuid

wizard_bp = Blueprint('wizard', __name__)

WIZARD_STEPS = [
    'general',
    'bts-pa', 
    'component',
    'certificate',
    'interception'
]

def get_session_config():
    """Get configuration from session or create new one"""
    if 'configuration' not in session:
        session['configuration'] = Configuration().to_dict()
        session['wizard_step'] = 'general'
        session['session_id'] = str(uuid.uuid4())
    
    config = Configuration()
    config.from_dict(session['configuration'])
    return config

def save_session_config(config):
    """Save configuration to session"""
    session['configuration'] = config.to_dict()
    session.permanent = True

def get_next_step(current_step):
    """Get next wizard step"""
    try:
        current_index = WIZARD_STEPS.index(current_step)
        if current_index < len(WIZARD_STEPS) - 1:
            return WIZARD_STEPS[current_index + 1]
    except ValueError:
        pass
    return None

def get_previous_step(current_step):
    """Get previous wizard step"""
    try:
        current_index = WIZARD_STEPS.index(current_step)
        if current_index > 0:
            return WIZARD_STEPS[current_index - 1]
    except ValueError:
        pass
    return None

@wizard_bp.route('/')
def index():
    """Landing page"""
    return render_template('index.html')

@wizard_bp.route('/new')
def new_config():
    """Start new configuration"""
    session.clear()  # Start fresh
    return redirect(url_for('wizard.wizard_step', step='general'))

@wizard_bp.route('/wizard/<step>', methods=['GET', 'POST'])
def wizard_step(step):
    """Handle individual wizard steps"""
    if step not in WIZARD_STEPS:
        return redirect(url_for('wizard.index'))
    
    config = get_session_config()
    session['wizard_step'] = step
    
    if request.method == 'POST':
        # Handle form submission
        if 'next' in request.form:
            # Validate current step and proceed
            errors = validate_step(step, request.form, config)
            if not errors:
                update_config_from_form(step, request.form, config)
                save_session_config(config)
                
                next_step = get_next_step(step)
                if next_step:
                    return redirect(url_for('wizard.wizard_step', step=next_step))
                else:
                    # Last step - redirect to package generation
                    return redirect(url_for('package.generate'))
            else:
                for error in errors:
                    flash(error, 'error')
        
        elif 'previous' in request.form:
            # Go to previous step without validation
            # But still save current form data
            update_config_from_form(step, request.form, config)
            save_session_config(config)
            
            previous_step = get_previous_step(step)
            if previous_step:
                return redirect(url_for('wizard.wizard_step', step=previous_step))
    
    # Render the appropriate template
    template_name = f'wizard/{step}.html'
    return render_template(template_name, 
                         config=config, 
                         step=step,
                         steps=WIZARD_STEPS,
                         current_step_index=WIZARD_STEPS.index(step))

def validate_step(step, form_data, config):
    """Validate form data for specific step"""
    from app.utils.validation_utils import ValidationUtils
    return ValidationUtils.validate_form_data(form_data, step)

def update_config_from_form(step, form_data, config):
    """Update configuration object from form data"""
    if step == 'general':
        config.general_settings.system_name = form_data.get('system_name', '')
        config.general_settings.serial_number = form_data.get('serial_number', '')
        config.general_settings.system_type = form_data.get('system_type', '')
        config.general_settings.add_scanner = 'add_scanner' in form_data
        config.general_settings.add_modems = 'add_modems' in form_data
        config.general_settings.generate_ssh_keys = 'generate_ssh_keys' in form_data
        config.general_settings.mobile_integration = 'mobile_integration' in form_data
        config.general_settings.interception_service = 'interception_service' in form_data
    
    elif step == 'bts-pa':
        config.bts_pa_config.bts_boards_count = int(form_data.get('bts_boards_count', 6))
        config.bts_pa_config.bts_board_type = form_data.get('bts_board_type', 'Dual')
        config.bts_pa_config.clock_sync = form_data.get('clock_sync', 'Internal')
        config.bts_pa_config.pa_tone = form_data.get('pa_tone', 'Single tone')
        
        # Handle PA configurations
        for i in range(1, 7):
            pa_key = f'pa{i}'
            pa_config = getattr(config.bts_pa_config, pa_key)
            pa_config.available = form_data.get(f'{pa_key}_available', 'AVAILABLE')
            
            # Get selected channels
            selected_channels = []
            for channel in [1,2,3,4,5,7,8,20,25,26,28,38,40,41,66]:
                if f'{pa_key}_channel_{channel}' in form_data:
                    selected_channels.append(channel)
            pa_config.selected_channels = selected_channels
    
    elif step == 'component':
        config.component_settings.core_network.umts_onv_sms_locs = form_data.get('umts_onv_sms_locs', 'Default')
        config.component_settings.core_network.bts_board_destination = form_data.get('bts_board_destination', 'Sequential')
        config.component_settings.subsystem.scanner_port = int(form_data.get('scanner_port', 4792))
        config.component_settings.scanner.hss_scanner = 'hss_scanner' in form_data
        config.component_settings.scanner.internal_scanner = 'internal_scanner' in form_data
        config.component_settings.scanner.ssv_bands_scan = form_data.get('ssv_bands_scan', '3.5')
        config.component_settings.scanner.umts_bands_scan = form_data.get('umts_bands_scan', '1.2')
        config.component_settings.scanner.lte_bands_scan = form_data.get('lte_bands_scan', '1,3,8,20,26,40,41,42')
        config.component_settings.scanner.nr_bands_scan = form_data.get('nr_bands_scan', '78')
        config.component_settings.antennas.use_omni_antennas = 'use_omni_antennas' in form_data
        config.component_settings.antennas.use_left_directional = 'use_left_directional' in form_data
        config.component_settings.antennas.use_right_directional = 'use_right_directional' in form_data
        config.component_settings.antenna_service.antenna_switch_type = form_data.get('antenna_switch_type', 'NUMATO')
        config.component_settings.antenna_service.omni_pin = int(form_data.get('omni_pin', 2))
        config.component_settings.antenna_service.left_pin = int(form_data.get('left_pin', 0))
        config.component_settings.antenna_service.right_pin = int(form_data.get('right_pin', 1))
        config.component_settings.antenna_service.use_relays_on_numato = 'use_relays_on_numato' in form_data
    
    elif step == 'certificate':
        config.certificate_config.ca_certificate.generation_option = form_data.get('ca_generation_option', '')
        config.certificate_config.ca_certificate.subject = form_data.get('ca_subject', '10.10.10')
        config.certificate_config.mikrotik_config.private_key = form_data.get('private_key', '')
        config.certificate_config.mikrotik_config.client_address = form_data.get('client_address', '')
        config.certificate_config.mikrotik_config.wireguard_server_ip = form_data.get('wireguard_server_ip', '')
        config.certificate_config.mikrotik_config.wireguard_client_endpoint = form_data.get('wireguard_client_endpoint', '')
        config.certificate_config.mikrotik_config.wireguard_client_port = form_data.get('wireguard_client_port', '')
        config.certificate_config.mikrotik_config.wireguard_public_key = form_data.get('wireguard_public_key', '')
        config.certificate_config.mikrotik_config.mercury_ip = form_data.get('mercury_ip', '')
        config.certificate_config.mikrotik_config.keybreaker_ip = form_data.get('keybreaker_ip', '')
        config.certificate_config.mercury_credentials.client_id = form_data.get('client_id', 'active-customer')
        config.certificate_config.mercury_credentials.client_secret = form_data.get('client_secret', '123456789012345678901234567890ACTIVE')
    
    elif step == 'interception':
        config.interception_service.enabled = 'interception_enabled' in form_data