import re
from typing import List, Dict, Any

class ValidationUtils:
    @staticmethod
    def validate_ip_address(ip: str) -> bool:
        """Validate IPv4 address format"""
        if not ip:
            return True  # Empty is allowed
        pattern = r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        return bool(re.match(pattern, ip))
    
    @staticmethod
    def validate_port(port: Any) -> bool:
        """Validate port number"""
        try:
            port_num = int(port)
            return 1 <= port_num <= 65535
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_required_field(value: Any) -> bool:
        """Check if required field has value"""
        if isinstance(value, str):
            return bool(value.strip())
        return value is not None
    
    @staticmethod
    def validate_numeric_range(value: Any, min_val: int, max_val: int) -> bool:
        """Validate numeric value within range"""
        try:
            num = int(value)
            return min_val <= num <= max_val
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_form_data(form_data: Dict[str, Any], step: str) -> List[str]:
        """Comprehensive form validation for each step"""
        errors = []
        
        if step == 'general':
            errors.extend(ValidationUtils._validate_general_settings(form_data))
        elif step == 'bts-pa':
            errors.extend(ValidationUtils._validate_bts_pa_settings(form_data))
        elif step == 'component':
            errors.extend(ValidationUtils._validate_component_settings(form_data))
        elif step == 'certificate':
            errors.extend(ValidationUtils._validate_certificate_settings(form_data))
        elif step == 'interception':
            errors.extend(ValidationUtils._validate_interception_settings(form_data))
        
        return errors
    
    @staticmethod
    def _validate_general_settings(form_data: Dict[str, Any]) -> List[str]:
        """Validate general settings form data"""
        errors = []
        
        # Required fields
        if not ValidationUtils.validate_required_field(form_data.get('system_name')):
            errors.append('System name is required')
        
        if not ValidationUtils.validate_required_field(form_data.get('serial_number')):
            errors.append('Serial number is required')
        
        if not ValidationUtils.validate_required_field(form_data.get('system_type')):
            errors.append('System type is required')
        
        # System name validation
        system_name = form_data.get('system_name', '')
        if len(system_name) > 50:
            errors.append('System name must be 50 characters or less')
        
        if system_name and not re.match(r'^[a-zA-Z0-9_-]+$', system_name):
            errors.append('System name can only contain letters, numbers, hyphens, and underscores')
        
        # Serial number validation
        serial_number = form_data.get('serial_number', '')
        if len(serial_number) > 30:
            errors.append('Serial number must be 30 characters or less')
        
        return errors
    
    @staticmethod
    def _validate_bts_pa_settings(form_data: Dict[str, Any]) -> List[str]:
        """Validate BTS and PA settings form data"""
        errors = []
        
        # BTS boards count validation
        bts_count = form_data.get('bts_boards_count')
        if not ValidationUtils.validate_numeric_range(bts_count, 1, 10):
            errors.append('BTS boards count must be between 1 and 10')
        
        # Validate PA configurations
        for i in range(1, 7):
            pa_key = f'pa{i}'
            available = form_data.get(f'{pa_key}_available', 'AVAILABLE')
            
            if available not in ['AVAILABLE', 'UNAVAILABLE']:
                errors.append(f'Invalid PA{i} availability setting')
        
        return errors
    
    @staticmethod
    def _validate_component_settings(form_data: Dict[str, Any]) -> List[str]:
        """Validate component settings form data"""
        errors = []
        
        # Scanner port validation
        scanner_port = form_data.get('scanner_port')
        if not ValidationUtils.validate_numeric_range(scanner_port, 1024, 65535):
            errors.append('Scanner port must be between 1024 and 65535')
        
        # Pin validation
        for pin_name in ['omni_pin', 'left_pin', 'right_pin']:
            pin_value = form_data.get(pin_name)
            if pin_value is not None and not ValidationUtils.validate_numeric_range(pin_value, 0, 7):
                errors.append(f'{pin_name.replace("_", " ").title()} must be between 0 and 7')
        
        # Band validation
        bands_fields = ['ssv_bands_scan', 'umts_bands_scan', 'lte_bands_scan', 'nr_bands_scan']
        for field in bands_fields:
            bands = form_data.get(field, '')
            if bands and not re.match(r'^[\d,.\s]+$', bands):
                errors.append(f'{field.replace("_", " ").title()} contains invalid characters')
        
        return errors
    
    @staticmethod
    def _validate_certificate_settings(form_data: Dict[str, Any]) -> List[str]:
        """Validate certificate settings form data"""
        errors = []
        
        # IP address validation
        ip_fields = ['client_address', 'wireguard_server_ip', 'mercury_ip', 'keybreaker_ip']
        for field in ip_fields:
            ip_value = form_data.get(field, '')
            if ip_value and not ValidationUtils.validate_ip_address(ip_value):
                errors.append(f'{field.replace("_", " ").title()} is not a valid IP address')
        
        # Port validation
        port_value = form_data.get('wireguard_client_port', '')
        if port_value and not ValidationUtils.validate_port(port_value):
            errors.append('Wireguard client port must be between 1 and 65535')
        
        # Client secret validation
        client_secret = form_data.get('client_secret', '')
        if client_secret and len(client_secret) < 10:
            errors.append('Client secret must be at least 10 characters long')
        
        return errors
    
    @staticmethod
    def _validate_interception_settings(form_data: Dict[str, Any]) -> List[str]:
        """Validate interception settings form data"""
        # No specific validation needed for interception settings currently
        return []