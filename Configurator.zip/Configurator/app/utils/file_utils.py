import os
import shutil
import tempfile
from typing import List
import time

class FileUtils:
    @staticmethod
    def cleanup_old_files(directory: str, max_age_hours: int = 24):
        """Clean up files older than specified hours"""
        if not os.path.exists(directory):
            return
        
        current_time = time.time()
        max_age_seconds = max_age_hours * 3600
        
        for filename in os.listdir(directory):
            file_path = os.path.join(directory, filename)
            if os.path.isfile(file_path):
                file_age = current_time - os.path.getctime(file_path)
                if file_age > max_age_seconds:
                    try:
                        os.remove(file_path)
                        print(f"Cleaned up old file: {filename}")
                    except Exception as e:
                        print(f"Error cleaning up {filename}: {str(e)}")
    
    @staticmethod
    def ensure_directory_exists(directory: str):
        """Ensure directory exists, create if it doesn't"""
        os.makedirs(directory, exist_ok=True)
    
    @staticmethod
    def safe_filename(filename: str) -> str:
        """Generate a safe filename"""
        # Remove or replace unsafe characters
        unsafe_chars = '<>:"/\\|?*'
        for char in unsafe_chars:
            filename = filename.replace(char, '_')
        return filename
    
    @staticmethod
    def get_file_size_mb(file_path: str) -> float:
        """Get file size in MB"""
        if os.path.exists(file_path):
            return os.path.getsize(file_path) / (1024 * 1024)
        return 0.0