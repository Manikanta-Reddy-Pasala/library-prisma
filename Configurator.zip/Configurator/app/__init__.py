from flask import Flask
import os

def create_app():
    app = Flask(__name__)
    
    # Configuration
    app.config['SECRET_KEY'] = os.environ.get('SECRET_KEY') or 'dev-secret-key-change-in-production'
    # Resolve project base directory (one level up from this file's directory)
    BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))
    app.config['BASE_DIR'] = BASE_DIR
    app.config['UPLOAD_FOLDER'] = os.path.join(BASE_DIR, 'uploads')
    app.config['GENERATED_PACKAGES_DIR'] = os.path.join(BASE_DIR, 'generated_packages')
    app.config['TEMP_DIR'] = os.path.join(BASE_DIR, 'temp')
    app.config['MAX_CONTENT_LENGTH'] = 16 * 1024 * 1024  # 16MB max file size
    
    # Ensure upload directory exists
    os.makedirs(app.config['UPLOAD_FOLDER'], exist_ok=True)
    os.makedirs(app.config['GENERATED_PACKAGES_DIR'], exist_ok=True)
    os.makedirs(app.config['TEMP_DIR'], exist_ok=True)
    
    # Register blueprints
    from app.routes.wizard import wizard_bp
    from app.routes.package import package_bp
    from app.routes.upload import upload_bp
    
    app.register_blueprint(wizard_bp)
    app.register_blueprint(package_bp)
    app.register_blueprint(upload_bp)
    
    return app