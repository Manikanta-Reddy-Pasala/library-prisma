from typing import Dict, List, Any, Optional
from dataclasses import dataclass, field, asdict
import re

@dataclass
class AttenuationTable:
    name: str = "Attenuation Table"
    value: str = "0.0B / 0.00%"

@dataclass
class GeneralSettings:
    system_name: str = ""
    serial_number: str = ""
    system_type: str = ""
    add_scanner: bool = False
    add_modems: bool = False
    generate_ssh_keys: bool = False
    mobile_integration: bool = False
    interception_service: bool = False
    attenuation_tables: List[AttenuationTable] = field(default_factory=lambda: [AttenuationTable()])
    
    def validate(self) -> List[str]:
        errors = []
        if not self.system_name.strip():
            errors.append("System name is required")
        if not self.serial_number.strip():
            errors.append("Serial number is required")
        if not self.system_type:
            errors.append("System type is required")
        return errors

@dataclass
class PAConfiguration:
    available: str = "AVAILABLE"
    selected_channels: List[int] = field(default_factory=list)

@dataclass
class BTSPAConfig:
    bts_boards_count: int = 6
    bts_board_type: str = "Dual"
    clock_sync: str = "Internal"
    pa_tone: str = "Single tone"
    pa1: PAConfiguration = field(default_factory=PAConfiguration)
    pa2: PAConfiguration = field(default_factory=PAConfiguration)
    pa3: PAConfiguration = field(default_factory=PAConfiguration)
    pa4: PAConfiguration = field(default_factory=PAConfiguration)
    pa5: PAConfiguration = field(default_factory=PAConfiguration)
    pa6: PAConfiguration = field(default_factory=PAConfiguration)
    
    def validate(self) -> List[str]:
        errors = []
        if self.bts_boards_count < 1 or self.bts_boards_count > 10:
            errors.append("BTS boards count must be between 1 and 10")
        return errors

@dataclass
class CoreNetworkConfig:
    umts_onv_sms_locs: str = "Default"
    bts_board_destination: str = "Sequential"

@dataclass
class SubsystemConfig:
    scanner_port: int = 4792

@dataclass
class ScannerConfig:
    hss_scanner: bool = False
    internal_scanner: bool = False
    ssv_bands_scan: str = "3.5"
    umts_bands_scan: str = "1.2"
    lte_bands_scan: str = "1,3,8,20,26,40,41,42"
    nr_bands_scan: str = "78"

@dataclass
class AntennaConfig:
    use_omni_antennas: bool = False
    use_left_directional: bool = False
    use_right_directional: bool = False

@dataclass
class AntennaServiceConfig:
    antenna_switch_type: str = "NUMATO"
    omni_pin: int = 2
    left_pin: int = 0
    right_pin: int = 1
    use_relays_on_numato: bool = False

@dataclass
class ComponentSettings:
    core_network: CoreNetworkConfig = field(default_factory=CoreNetworkConfig)
    subsystem: SubsystemConfig = field(default_factory=SubsystemConfig)
    scanner: ScannerConfig = field(default_factory=ScannerConfig)
    antennas: AntennaConfig = field(default_factory=AntennaConfig)
    antenna_service: AntennaServiceConfig = field(default_factory=AntennaServiceConfig)
    
    def validate(self) -> List[str]:
        errors = []
        if self.subsystem.scanner_port < 1024 or self.subsystem.scanner_port > 65535:
            errors.append("Scanner port must be between 1024 and 65535")
        return errors

@dataclass
class CACertConfig:
    generation_option: str = ""
    subject: str = "10.10.10"

@dataclass
class MikrotikConfig:
    private_key: str = ""
    client_address: str = ""
    wireguard_server_ip: str = ""
    wireguard_client_endpoint: str = ""
    wireguard_client_port: str = ""
    wireguard_public_key: str = ""
    mercury_ip: str = ""
    keybreaker_ip: str = ""

@dataclass
class MercuryCredentials:
    client_id: str = "active-customer"
    client_secret: str = "123456789012345678901234567890ACTIVE"

@dataclass
class CertificateConfig:
    ca_certificate: CACertConfig = field(default_factory=CACertConfig)
    mikrotik_config: MikrotikConfig = field(default_factory=MikrotikConfig)
    mercury_credentials: MercuryCredentials = field(default_factory=MercuryCredentials)
    
    def validate(self) -> List[str]:
        errors = []
        # IP address validation
        ip_pattern = r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        
        if self.mikrotik_config.client_address and not re.match(ip_pattern, self.mikrotik_config.client_address):
            errors.append("Invalid client address format")
        if self.mikrotik_config.wireguard_server_ip and not re.match(ip_pattern, self.mikrotik_config.wireguard_server_ip):
            errors.append("Invalid Wireguard server IP format")
        if self.mikrotik_config.mercury_ip and not re.match(ip_pattern, self.mikrotik_config.mercury_ip):
            errors.append("Invalid Mercury IP format")
        if self.mikrotik_config.keybreaker_ip and not re.match(ip_pattern, self.mikrotik_config.keybreaker_ip):
            errors.append("Invalid Keybreaker IP format")
            
        return errors

@dataclass
class InterceptionServiceConfig:
    enabled: bool = False
    
    def validate(self) -> List[str]:
        return []

class Configuration:
    def __init__(self):
        self.general_settings = GeneralSettings()
        self.bts_pa_config = BTSPAConfig()
        self.component_settings = ComponentSettings()
        self.certificate_config = CertificateConfig()
        self.interception_service = InterceptionServiceConfig()
    
    def to_dict(self) -> Dict[str, Any]:
        return {
            'general_settings': asdict(self.general_settings),
            'bts_pa_config': asdict(self.bts_pa_config),
            'component_settings': asdict(self.component_settings),
            'certificate_config': asdict(self.certificate_config),
            'interception_service': asdict(self.interception_service)
        }
    
    def from_dict(self, data: Dict[str, Any]):
        if 'general_settings' in data:
            self.general_settings = GeneralSettings(**data['general_settings'])
        if 'bts_pa_config' in data:
            bts_data = data['bts_pa_config']
            # Handle PA configurations
            for pa_key in ['pa1', 'pa2', 'pa3', 'pa4', 'pa5', 'pa6']:
                if pa_key in bts_data and isinstance(bts_data[pa_key], dict):
                    bts_data[pa_key] = PAConfiguration(**bts_data[pa_key])
            self.bts_pa_config = BTSPAConfig(**bts_data)
        if 'component_settings' in data:
            comp_data = data['component_settings']
            if 'core_network' in comp_data:
                comp_data['core_network'] = CoreNetworkConfig(**comp_data['core_network'])
            if 'subsystem' in comp_data:
                comp_data['subsystem'] = SubsystemConfig(**comp_data['subsystem'])
            if 'scanner' in comp_data:
                comp_data['scanner'] = ScannerConfig(**comp_data['scanner'])
            if 'antennas' in comp_data:
                comp_data['antennas'] = AntennaConfig(**comp_data['antennas'])
            if 'antenna_service' in comp_data:
                comp_data['antenna_service'] = AntennaServiceConfig(**comp_data['antenna_service'])
            self.component_settings = ComponentSettings(**comp_data)
        if 'certificate_config' in data:
            cert_data = data['certificate_config']
            if 'ca_certificate' in cert_data:
                cert_data['ca_certificate'] = CACertConfig(**cert_data['ca_certificate'])
            if 'mikrotik_config' in cert_data:
                cert_data['mikrotik_config'] = MikrotikConfig(**cert_data['mikrotik_config'])
            if 'mercury_credentials' in cert_data:
                cert_data['mercury_credentials'] = MercuryCredentials(**cert_data['mercury_credentials'])
            self.certificate_config = CertificateConfig(**cert_data)
        if 'interception_service' in data:
            self.interception_service = InterceptionServiceConfig(**data['interception_service'])
    
    def validate(self) -> Dict[str, List[str]]:
        errors = {}
        
        general_errors = self.general_settings.validate()
        if general_errors:
            errors['general_settings'] = general_errors
            
        bts_errors = self.bts_pa_config.validate()
        if bts_errors:
            errors['bts_pa_config'] = bts_errors
            
        component_errors = self.component_settings.validate()
        if component_errors:
            errors['component_settings'] = component_errors
            
        cert_errors = self.certificate_config.validate()
        if cert_errors:
            errors['certificate_config'] = cert_errors
            
        interception_errors = self.interception_service.validate()
        if interception_errors:
            errors['interception_service'] = interception_errors
            
        return errors