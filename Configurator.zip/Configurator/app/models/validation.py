import re
from typing import List, Any

class ValidationUtils:
    @staticmethod
    def validate_ip_address(ip: str) -> bool:
        """Validate IPv4 address format"""
        if not ip:
            return True  # Empty is allowed
        pattern = r'^(?:(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)\.){3}(?:25[0-5]|2[0-4][0-9]|[01]?[0-9][0-9]?)$'
        return bool(re.match(pattern, ip))
    
    @staticmethod
    def validate_port(port: Any) -> bool:
        """Validate port number"""
        try:
            port_num = int(port)
            return 1 <= port_num <= 65535
        except (ValueError, TypeError):
            return False
    
    @staticmethod
    def validate_required_field(value: Any) -> bool:
        """Check if required field has value"""
        if isinstance(value, str):
            return bool(value.strip())
        return value is not None
    
    @staticmethod
    def validate_numeric_range(value: Any, min_val: int, max_val: int) -> bool:
        """Validate numeric value within range"""
        try:
            num = int(value)
            return min_val <= num <= max_val
        except (ValueError, TypeError):
            return False