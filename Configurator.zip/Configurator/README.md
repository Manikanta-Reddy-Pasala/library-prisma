# Cellular Configurator

A comprehensive web-based wizard application for configuring cellular network systems. The application generates dynamic configuration files using Jinja2 templates and packages them into Debian packages for deployment.

## Features

- **Wizard-based Interface**: Step-by-step configuration process with 5 main sections
- **Dynamic Configuration Generation**: Uses Jinja2 templates to generate configuration files
- **Debian Package Creation**: Automatically creates deployment packages
- **Configuration Editing**: Upload and edit existing configurations
- **Responsive Design**: Works on desktop, tablet, and mobile devices
- **Form Validation**: Comprehensive client and server-side validation
- **File Management**: Automatic cleanup of temporary files

## Configuration Sections

1. **General Settings**: System name, type, serial number, and basic features
2. **BTS and PA Configuration**: Radio frequency component setup
3. **Component Settings**: Network infrastructure configuration
4. **Certificate**: Security and VPN configuration
5. **Interception Service**: Lawful interception capabilities

## Installation

### Prerequisites

- Python 3.7 or higher
- pip3

### Quick Start

1. Clone or download the project
2. Run the startup script:
   ```bash
   ./start.sh
   ```
3. Open your browser and navigate to `http://localhost:5000`

### Manual Installation

1. Install dependencies:
   ```bash
   pip3 install -r requirements.txt
   ```

2. Create necessary directories:
   ```bash
   mkdir -p uploads generated_packages temp config_templates
   ```

3. Run the application:
   ```bash
   python3 run.py
   ```

## Usage

### Creating a New Configuration

1. Click "New Configuration" or "Start Wizard"
2. Fill out each step of the wizard:
   - General Settings
   - BTS and PA Configuration
   - Component Settings
   - Certificate
   - Interception Service
3. Click "CREATE CONFIGURATION PACKAGE" on the final step
4. Download the generated ZIP package

### Editing an Existing Configuration

1. Click "Upload Configuration"
2. Select a previously generated ZIP file
3. The wizard will be populated with existing values
4. Make your changes and regenerate the package

## Generated Package Structure

The generated package contains:

```
package.tar.gz
├── DEBIAN/
│   ├── control
│   ├── postinst
│   └── prerm
└── opt/
    └── config/
        ├── cellular.d/
        ├── certs/
        ├── corenetwork.d/
        ├── identity.d/
        ├── keys/
        ├── rcu.d/
        ├── services.d/
        └── subsystem.d/
```

The ZIP download includes:
- Configuration package (tar.gz)
- ui.ini file (for editing)
- README.txt (installation instructions)

## Configuration Templates

The application uses Jinja2 templates located in `config_templates/` to generate dynamic configuration files. Each template corresponds to a specific configuration file in the package structure.

## API Endpoints

- `GET /` - Home page
- `GET/POST /wizard/<step>` - Wizard steps
- `POST /generate` - Generate configuration package
- `GET /download` - Download generated package
- `GET/POST /upload` - Upload existing configuration

## File Structure

```
cellular-configurator/
├── app/
│   ├── __init__.py
│   ├── models/
│   │   ├── configuration.py
│   │   └── validation.py
│   ├── routes/
│   │   ├── wizard.py
│   │   ├── package.py
│   │   └── upload.py
│   ├── services/
│   │   ├── template_service.py
│   │   ├── package_service.py
│   │   └── config_loader.py
│   ├── templates/
│   │   ├── base.html
│   │   ├── index.html
│   │   ├── wizard/
│   │   ├── package/
│   │   └── upload/
│   └── utils/
├── config_templates/
├── requirements.txt
├── run.py
├── start.sh
└── README.md
```

## Security Considerations

- Input validation on all form fields
- File upload restrictions (ZIP files only, size limits)
- Secure file handling with temporary directories
- CSRF protection on all forms
- Sanitized template processing

## Browser Support

- Chrome 60+
- Firefox 55+
- Safari 12+
- Edge 79+

## Troubleshooting

### Common Issues

1. **Port already in use**: Change the port in `run.py`
2. **Permission errors**: Ensure write permissions for upload directories
3. **Template errors**: Check Jinja2 template syntax in `config_templates/`
4. **Package generation fails**: Verify all required fields are filled

### Logs

Application logs are printed to the console. For production deployment, configure proper logging.

## Development

### Adding New Configuration Fields

1. Update the appropriate model in `app/models/configuration.py`
2. Add form fields to the corresponding template in `app/templates/wizard/`
3. Update the form processing in `app/routes/wizard.py`
4. Create or update Jinja2 templates in `config_templates/`
5. Update field mappings in `app/services/template_service.py`

### Customizing Templates

Edit the Jinja2 templates in `config_templates/` to customize the generated configuration files. The templates have access to the full configuration object.

## License

This project is provided as-is for educational and development purposes.

## Support

For issues and questions, please check the troubleshooting section or review the application logs for error details.