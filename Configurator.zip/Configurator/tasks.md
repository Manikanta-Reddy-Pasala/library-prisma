<!-- @format -->

# Implementation Plan

- [x] 1. Set up project structure and core Flask application

  - Create Flask application factory with proper directory structure
  - Set up basic routing, session management, and configuration
  - Create requirements.txt with Flask, Jinja2, and other dependencies
  - _Requirements: 1.1, 8.1_

- [x] 2. Implement configuration data models and validation

  - Create Configuration base class and individual section classes (GeneralSettings, BTSPAConfig, ComponentSettings, CertificateConfig)
  - Implement validation methods for each configuration section
  - Add serialization methods (to_dict, from_dict) for session storage
  - Write unit tests for all model classes and validation logic
  - _Requirements: 2.1, 2.2, 3.1, 4.1, 5.1, 8.4_

- [x] 3. Create wizard navigation and session management

  - Implement wizard route handlers for each step (general, bts-pa, component, certificate, interception)
  - Create session management utilities for storing and retrieving configuration state
  - Implement navigation logic with Previous/Next buttons and step validation
  - Write tests for wizard navigation and session persistence
  - _Requirements: 1.1, 1.2, 1.3, 1.4, 1.5_

- [x] 4. Build General Settings form and processing

  - Create HTML template for General Settings wizard step with all required fields
  - Implement form processing for system name, serial number, system type dropdown
  - Add toggle switches for scanner, modems, SSH keys, mobile integration, interception service
  - Implement attenuation tables section with add/remove functionality
  - Write tests for General Settings form validation and processing
  - _Requirements: 2.1, 2.2, 2.3, 2.4, 2.5_

- [x] 5. Build BTS and PA Configuration form and processing

  - Create HTML template for BTS and PA Configuration with BTS board settings
  - Implement PA settings with PA1-PA6 sections and selectable button grids
  - Add JavaScript for interactive PA button selection and highlighting
  - Implement form processing and validation for all BTS/PA fields
  - Write tests for BTS/PA configuration processing
  - _Requirements: 3.1, 3.2, 3.3, 3.4, 3.5_

- [x] 6. Build Component Settings form and processing

  - Create HTML template for Component Settings with CoreNetwork and Subsystem sections
  - Implement Scanner settings with toggles and frequency fields
  - Add Antennas Connected section with multiple toggle options
  - Implement Antenna Service section with dropdown and pin configurations
  - Write tests for Component Settings form validation and processing
  - _Requirements: 4.1, 4.2, 4.3, 4.4, 4.5, 4.6_

- [x] 7. Build Certificate configuration form and processing

  - Create HTML template for Certificate step with CA certificate section
  - Implement Mikrotik Configuration section with all network fields
  - Add System credentials for Mercury with client ID/secret and generation button
  - Implement IP address validation and credential generation functionality
  - Write tests for Certificate configuration processing and validation
  - _Requirements: 5.1, 5.2, 5.3, 5.4, 5.5_

- [x] 8. Create Jinja2 template system for configuration files

  - Create template directory structure matching the optconfig folder layout
  - Implement Jinja2 templates for each configuration file type (cellular, corenetwork, identity, etc.)
  - Create TemplateService class for rendering templates with configuration data
  - Implement template mapping system to link form fields to template variables
  - Write tests for template rendering with various configuration combinations
  - _Requirements: 8.1, 8.2, 8.3, 8.4, 8.5_

- [x] 9. Implement Debian package generation service

  - Create PackageService class for generating Debian packages
  - Implement optconfig folder structure creation with proper subdirectories
  - Add DEBIAN control files generation (control, postinst, prerm)
  - Implement package building using Python dpkg utilities or subprocess calls
  - Write tests for package generation and structure validation
  - _Requirements: 6.1, 6.2, 6.3, 6.4_

- [x] 10. Create ui.ini file generation and mapping system

  - Implement ui.ini file generation with field-to-file mappings
  - Create mapping configuration that links form fields to configuration file locations
  - Add template mapping section to ui.ini for template references
  - Implement ZIP package creation containing both .deb and ui.ini files
  - Write tests for ui.ini generation and ZIP package creation
  - _Requirements: 6.5, 6.6_

- [x] 11. Implement configuration loading from ZIP files

  - Create ConfigLoader service for parsing uploaded ZIP files
  - Implement ui.ini parsing to extract field mappings and template references
  - Add configuration file parsing to extract values based on mappings
  - Implement Configuration object population from loaded values
  - Write tests for configuration loading and parsing accuracy
  - _Requirements: 7.1, 7.2, 7.3, 7.4_

- [x] 12. Build file upload and configuration editing functionality

  - Create file upload interface with drag-and-drop support
  - Implement ZIP file validation and processing
  - Add configuration loading integration with wizard form population
  - Implement edit mode navigation with pre-populated form fields
  - Write tests for upload processing and form population
  - _Requirements: 7.1, 7.2, 7.3, 7.4, 7.5_

- [x] 13. Create package download and regeneration system

  - Implement package download routes with proper file serving
  - Add package ID tracking for download management
  - Implement regeneration functionality for edited configurations
  - Create cleanup system for temporary files and old packages
  - Write tests for download functionality and file cleanup
  - _Requirements: 6.6, 7.5_

- [x] 14. Add comprehensive form validation and error handling

  - Implement client-side validation using HTML5 and JavaScript
  - Add server-side validation for all form fields and data types
  - Create error display system with inline field error messages
  - Implement validation error recovery and user feedback
  - Write tests for all validation scenarios and error handling
  - _Requirements: 1.4, 2.5, 3.5, 4.6, 5.5, 8.5_

- [x] 15. Create responsive UI styling and JavaScript interactions

  - Implement CSS styling for wizard interface and form components
  - Add responsive design for mobile and tablet compatibility
  - Create JavaScript for dynamic form interactions (toggles, button selections)
  - Implement progress indicators and step navigation enhancements
  - Write frontend tests for UI interactions and responsiveness
  - _Requirements: 1.1, 1.2, 3.4_

- [x] 16. Integrate all components and implement end-to-end workflow
  - Connect all wizard steps with proper data flow and validation
  - Integrate template processing with package generation
  - Connect upload functionality with configuration editing workflow
  - Implement complete generate → download → upload → edit → regenerate cycle
  - Write integration tests for complete application workflows
  - _Requirements: 1.1, 6.1, 7.1, 7.5_
