# Requirements Document

## Introduction

The Cellular Configurator is a web-based wizard application that guides users through configuring cellular network systems. The application features a multi-step wizard interface with five main configuration sections: General Settings, BTS and PA Configuration, Component Settings, Certificate, and Interception Service. The configurator generates dynamic configuration files using Jinja2 templates and packages them into Debian packages. Additionally, it supports editing existing configurations by loading from ZIP files containing UI.ini files that map form fields to their corresponding configuration files.

## Requirements

### Requirement 1

**User Story:** As a network administrator, I want to navigate through a wizard-based interface with multiple configuration sections, so that I can systematically configure all aspects of my cellular network system.

#### Acceptance Criteria

1. WHEN the user accesses the application THEN the system SHALL display a wizard interface with five navigation sections in the left sidebar: General Settings, BTS and PA Configuration, Component Settings, Certificate, and Interception Service
2. WHEN the user clicks on a navigation section THEN the system SHALL display the corresponding configuration form
3. WHEN the user is on any step THEN the system SHALL show Previous and Next navigation buttons
4. WHEN the user clicks Next THEN the system SHALL validate the current form and proceed to the next step if valid
5. WHEN the user clicks Previous THEN the system SHALL navigate to the previous step without validation

### Requirement 2

**User Story:** As a network administrator, I want to configure general system settings including system name, serial number, system type, and various system options, so that I can establish the basic system parameters.

#### Acceptance Criteria

1. WHEN the user is on the General Settings screen THEN the system SHALL display text fields for System Name and Serial Number
2. WHEN the user is on the General Settings screen THEN the system SHALL display a dropdown for System Type selection
3. WHEN the user is on the General Settings screen THEN the system SHALL display toggle switches for: Add Scanner to system, Add modems to system, Generate SSH Keys, Mobile Integration, and Interception Service
4. WHEN the user is on the General Settings screen THEN the system SHALL display a System Attenuation Tables section with an "Attenuation Table" component showing "0.0B / 0.00%" with an add button
5. WHEN the user toggles any switch THEN the system SHALL update the configuration state accordingly

### Requirement 3

**User Story:** As a network administrator, I want to configure BTS board settings and PA settings with multiple selectable options, so that I can set up the radio frequency components of my system.

#### Acceptance Criteria

1. WHEN the user is on the BTS and PA Configuration screen THEN the system SHALL display BTS board settings with fields for: Number of BTS boards, BTS board type dropdown, and Clock synchronization dropdown
2. WHEN the user is on the BTS and PA Configuration screen THEN the system SHALL display PA settings with PA tone dropdown
3. WHEN the user is on the BTS and PA Configuration screen THEN the system SHALL display PA1 through PA6 sections each with an "AVAILABLE" dropdown and numbered selection buttons (1,2,3,4,5,7,8,20,25,26,28,38,40,41,66)
4. WHEN the user selects PA options THEN the system SHALL highlight selected buttons in green
5. WHEN the user changes any BTS or PA setting THEN the system SHALL update the configuration state

### Requirement 4

**User Story:** As a network administrator, I want to configure component settings including CoreNetwork, Subsystem, Scanner, and Antenna configurations, so that I can set up the network infrastructure components.

#### Acceptance Criteria

1. WHEN the user is on the Component Settings screen THEN the system SHALL display CoreNetwork settings with UMTS/OnV/Sms/Locs dropdown and BTS board destination type dropdown
2. WHEN the user is on the Component Settings screen THEN the system SHALL display Subsystem settings with Scanner port field
3. WHEN the user is on the Component Settings screen THEN the system SHALL display Scanner settings with HSS Scanner toggle and Internal Scanner toggle
4. WHEN the user is on the Component Settings screen THEN the system SHALL display scanner frequency fields for different bands
5. WHEN the user is on the Component Settings screen THEN the system SHALL display Antennas Connected section with toggles for Omni antennas, Directional antennas, and Right Directional antennas
6. WHEN the user is on the Component Settings screen THEN the system SHALL display Antenna Service section with dropdown for antenna switch type and pin configuration fields

### Requirement 5

**User Story:** As a network administrator, I want to configure certificate settings and Mikrotik configuration parameters, so that I can establish secure communications and VPN connectivity.

#### Acceptance Criteria

1. WHEN the user is on the Certificate screen THEN the system SHALL display CA certificate section with dropdown for certificate generation options and Subject field
2. WHEN the user is on the Certificate screen THEN the system SHALL display Mikrotik Configuration section with fields for: Private Key, Client Address, Wireguard Server Internal IP, Wireguard Client Endpoint, Wireguard Client Port, Wireguard Public Key, Mercury IP, and Keybreaker IP
3. WHEN the user is on the Certificate screen THEN the system SHALL display System credentials for Mercury section with Client ID field and Client Secret field
4. WHEN the user clicks "GENERATE UNIQUE CREDENTIALS" THEN the system SHALL populate the Client Secret field with a generated value
5. WHEN the user fills certificate information THEN the system SHALL validate the format of IP addresses and other technical fields

### Requirement 6

**User Story:** As a network administrator, I want to generate a Debian package containing all configuration files based on my wizard inputs, so that I can deploy the configuration to target systems.

#### Acceptance Criteria

1. WHEN the user completes all wizard steps and clicks "CREATE CONFIGURATION PACKAGE" THEN the system SHALL generate a Debian package (.deb file)
2. WHEN generating the package THEN the system SHALL create an optconfig folder structure with subdirectories: cellular.d, certs, corenetwork.d, identity.d, keys, rcu.d, services.d, subsystem.d
3. WHEN generating configuration files THEN the system SHALL use Jinja2 templates to populate dynamic content based on form field values
4. WHEN generating configuration files THEN the system SHALL map form fields to appropriate configuration files (one-to-many mapping)
5. WHEN the package is generated THEN the system SHALL include a ui.ini file that maps form fields to their corresponding file locations and sections
6. WHEN the package generation is complete THEN the system SHALL provide the Debian package as a downloadable ZIP file

### Requirement 7

**User Story:** As a network administrator, I want to load an existing configuration from a ZIP file containing a ui.ini file, so that I can edit previously created configurations.

#### Acceptance Criteria

1. WHEN the user uploads a ZIP file containing a ui.ini file THEN the system SHALL parse the ui.ini file to extract field mappings
2. WHEN loading a configuration THEN the system SHALL read the configuration files referenced in the ui.ini file
3. WHEN loading a configuration THEN the system SHALL populate the wizard form fields with values from the loaded configuration files
4. WHEN the configuration is loaded THEN the system SHALL allow the user to navigate through all wizard steps with pre-populated values
5. WHEN the user modifies a loaded configuration and regenerates THEN the system SHALL create a new Debian package with updated values and a new ui.ini file

### Requirement 8

**User Story:** As a developer, I want the application to use Jinja2 templates for all configuration file generation, so that the system can dynamically generate content based on user inputs.

#### Acceptance Criteria

1. WHEN the system generates configuration files THEN it SHALL use Jinja2 templates for all file content generation
2. WHEN using templates THEN the system SHALL support conditional content based on user selections (e.g., toggle switches)
3. WHEN using templates THEN the system SHALL support iterative content for multi-value fields (e.g., PA configurations)
4. WHEN templates are processed THEN the system SHALL handle different data types including text, numbers, booleans, and lists
5. WHEN template processing fails THEN the system SHALL provide clear error messages indicating the template and field causing the issue