# Design Document

## Overview

The Cellular Configurator is a Flask-based web application that provides a wizard interface for configuring cellular network systems. The application uses a multi-step form approach with server-side session management to maintain state across wizard steps. Configuration data is processed through Jinja2 templates to generate dynamic configuration files, which are then packaged into Debian packages for deployment.

## Architecture

### High-Level Architecture

```
┌─────────────────┐    ┌─────────────────┐    ┌─────────────────┐
│   Web Browser   │◄──►│  Flask Web App  │◄──►│  File System    │
│                 │    │                 │    │                 │
│ - Wizard UI     │    │ - Route Handlers│    │ - Templates     │
│ - Form Validation│    │ - Session Mgmt  │    │ - Generated     │
│ - File Upload   │    │ - Template Proc │    │   Configs       │
└─────────────────┘    └─────────────────┘    └─────────────────┘
                                │
                                ▼
                       ┌─────────────────┐
                       │ Package Builder │
                       │                 │
                       │ - Debian Pkg    │
                       │ - ZIP Creation  │
                       │ - ui.ini Gen    │
                       └─────────────────┘
```

### Technology Stack

- **Backend**: Python Flask
- **Frontend**: HTML5, CSS3, JavaScript (vanilla)
- **Templating**: Jinja2 (both for web templates and config file generation)
- **Session Management**: Flask sessions with server-side storage
- **File Processing**: Python standard library (zipfile, configparser)
- **Package Creation**: Custom Debian package builder using Python

## Components and Interfaces

### 1. Web Application Layer

#### Flask Application Structure
```
app/
├── __init__.py              # Flask app factory
├── routes/
│   ├── __init__.py
│   ├── wizard.py            # Wizard step routes
│   ├── package.py           # Package generation routes
│   └── upload.py            # Configuration upload routes
├── models/
│   ├── __init__.py
│   ├── configuration.py     # Configuration data models
│   └── validation.py        # Form validation logic
├── services/
│   ├── __init__.py
│   ├── template_service.py  # Jinja2 template processing
│   ├── package_service.py   # Debian package creation
│   └── config_loader.py     # Configuration file parsing
└── utils/
    ├── __init__.py
    ├── file_utils.py        # File manipulation utilities
    └── validation_utils.py  # Validation helpers
```

#### Route Definitions
- `GET/POST /` - Landing page and wizard start
- `GET/POST /wizard/<step>` - Individual wizard steps (general, bts-pa, component, certificate, interception)
- `POST /generate-package` - Generate and download Debian package
- `POST /upload-config` - Upload and parse existing configuration
- `GET /download/<package_id>` - Download generated packages

### 2. Configuration Data Models

#### Configuration Class
```python
class Configuration:
    def __init__(self):
        self.general_settings = GeneralSettings()
        self.bts_pa_config = BTSPAConfig()
        self.component_settings = ComponentSettings()
        self.certificate_config = CertificateConfig()
        self.interception_service = InterceptionServiceConfig()
    
    def to_dict(self):
        # Convert to dictionary for template processing
    
    def from_dict(self, data):
        # Load from dictionary (for session restoration)
    
    def validate(self):
        # Validate all configuration sections
```

#### Individual Configuration Sections
```python
class GeneralSettings:
    system_name: str
    serial_number: str
    system_type: str
    add_scanner: bool
    add_modems: bool
    generate_ssh_keys: bool
    mobile_integration: bool
    interception_service: bool
    attenuation_tables: List[AttenuationTable]

class BTSPAConfig:
    bts_boards_count: int
    bts_board_type: str
    clock_sync: str
    pa_tone: str
    pa_configurations: Dict[str, PAConfiguration]  # PA1-PA6

class ComponentSettings:
    core_network: CoreNetworkConfig
    subsystem: SubsystemConfig
    scanner: ScannerConfig
    antennas: AntennaConfig

class CertificateConfig:
    ca_certificate: CACertConfig
    mikrotik_config: MikrotikConfig
    mercury_credentials: MercuryCredentials
```

### 3. Template Processing Service

#### Template Service Interface
```python
class TemplateService:
    def __init__(self, template_dir: str):
        self.jinja_env = Environment(loader=FileSystemLoader(template_dir))
    
    def render_config_file(self, template_name: str, config_data: dict) -> str:
        # Render individual configuration file
    
    def render_all_configs(self, config: Configuration) -> Dict[str, str]:
        # Render all configuration files for the given configuration
    
    def get_template_mapping(self) -> Dict[str, List[str]]:
        # Return mapping of form fields to template files
```

#### Template Directory Structure
```
config_templates/
├── cellular/
│   ├── product-type.conf.j2
│   └── system-specific.conf.j2
├── corenetwork/
│   └── system-specific.conf.j2
├── identity/
│   └── system-specific.conf.j2
├── rcu/
│   └── system-specific.conf.j2
├── services/
│   └── system-specific.conf.j2
└── subsystem/
    └── system-specific.conf.j2
```

### 4. Package Generation Service

#### Package Service Interface
```python
class PackageService:
    def create_debian_package(self, config: Configuration, package_name: str) -> str:
        # Create Debian package with configuration files
    
    def create_ui_ini(self, config: Configuration) -> str:
        # Generate ui.ini file with field mappings
    
    def create_zip_package(self, deb_path: str, ui_ini_content: str) -> str:
        # Create ZIP file containing .deb and ui.ini
```

#### Package Structure
```
generated_package.deb
├── DEBIAN/
│   ├── control
│   ├── postinst
│   └── prerm
└── opt/
    └── config/
        ├── cellular.d/
        │   ├── product-type.conf
        │   └── system-specific.conf
        ├── certs/
        ├── corenetwork.d/
        │   └── system-specific.conf
        ├── identity.d/
        │   └── system-specific.conf
        ├── keys/
        ├── rcu.d/
        │   └── system-specific.conf
        ├── services.d/
        │   └── system-specific.conf
        └── subsystem.d/
            └── system-specific.conf
```

### 5. Configuration Loading Service

#### Config Loader Interface
```python
class ConfigLoader:
    def load_from_zip(self, zip_path: str) -> Configuration:
        # Extract and parse configuration from ZIP file
    
    def parse_ui_ini(self, ini_content: str) -> Dict[str, str]:
        # Parse ui.ini file to get field mappings
    
    def extract_config_values(self, config_files: Dict[str, str], 
                            field_mappings: Dict[str, str]) -> Configuration:
        # Extract values from config files based on mappings
```

## Data Models

### Session Data Structure
```python
session_data = {
    'wizard_step': 'general',  # Current wizard step
    'configuration': {
        'general_settings': {...},
        'bts_pa_config': {...},
        'component_settings': {...},
        'certificate_config': {...},
        'interception_service': {...}
    },
    'validation_errors': {...},
    'package_id': 'uuid-string'  # For download tracking
}
```

### UI.ini File Format
```ini
[field_mappings]
general.system_name = cellular.d/system-specific.conf:system.name
general.serial_number = cellular.d/system-specific.conf:system.serial
general.system_type = cellular.d/product-type.conf:product.type
bts_pa.bts_boards_count = corenetwork.d/system-specific.conf:bts.boards
bts_pa.pa1_selection = rcu.d/system-specific.conf:pa.pa1.channels
certificate.ca_subject = identity.d/system-specific.conf:ca.subject
...

[file_templates]
cellular.d/product-type.conf = product-type.conf.j2
cellular.d/system-specific.conf = cellular-system.conf.j2
corenetwork.d/system-specific.conf = corenetwork-system.conf.j2
...
```

## Error Handling

### Validation Strategy
1. **Client-side validation**: Basic field validation using HTML5 and JavaScript
2. **Server-side validation**: Comprehensive validation in Flask routes
3. **Template validation**: Validation during template rendering
4. **Package validation**: Validation during package creation

### Error Types and Handling
```python
class ConfigurationError(Exception):
    """Base exception for configuration errors"""

class ValidationError(ConfigurationError):
    """Field validation errors"""
    
class TemplateError(ConfigurationError):
    """Template processing errors"""
    
class PackageError(ConfigurationError):
    """Package generation errors"""

# Error handling in routes
@app.errorhandler(ValidationError)
def handle_validation_error(error):
    return render_template('wizard_step.html', 
                         errors=error.errors, 
                         config=session['configuration'])
```

### Error Recovery
- **Form validation errors**: Display errors inline with form fields
- **Template errors**: Log detailed error and show user-friendly message
- **Package generation errors**: Provide retry mechanism and error details
- **File upload errors**: Validate file format and provide clear feedback

## Testing Strategy

### Unit Testing
- **Model validation**: Test all configuration model validation logic
- **Template rendering**: Test template processing with various input combinations
- **Package generation**: Test Debian package creation and structure
- **Configuration loading**: Test parsing of various ui.ini and config file formats

### Integration Testing
- **Wizard flow**: Test complete wizard navigation and data persistence
- **Package round-trip**: Test generate → upload → edit → regenerate cycle
- **Template integration**: Test end-to-end template processing with real data
- **File handling**: Test ZIP upload, extraction, and processing

### Frontend Testing
- **Form validation**: Test client-side validation for all form fields
- **Navigation**: Test wizard step navigation and state management
- **File upload**: Test drag-and-drop and file selection functionality
- **Responsive design**: Test UI across different screen sizes

### Performance Testing
- **Template rendering**: Test performance with large configuration sets
- **Package generation**: Test generation time for various package sizes
- **File upload**: Test handling of large ZIP files
- **Concurrent users**: Test session management with multiple simultaneous users

## Security Considerations

### Input Validation
- Sanitize all user inputs to prevent injection attacks
- Validate file uploads (type, size, content)
- Implement CSRF protection for all forms
- Use secure session management

### File Security
- Restrict file upload types and sizes
- Scan uploaded files for malicious content
- Use temporary directories with proper cleanup
- Implement secure file download mechanisms

### Template Security
- Use Jinja2 sandboxed environment for config templates
- Validate template syntax before processing
- Prevent template injection attacks
- Limit template complexity and execution time