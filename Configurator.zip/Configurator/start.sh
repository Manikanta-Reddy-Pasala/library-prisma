#!/bin/bash

# Cellular Configurator Startup Script

echo "Starting Cellular Configurator..."

# Check if Python is installed
if ! command -v python3 &> /dev/null; then
    echo "Python 3 is required but not installed. Please install Python 3."
    exit 1
fi

# Check if pip is installed
if ! command -v pip3 &> /dev/null; then
    echo "pip3 is required but not installed. Please install pip3."
    exit 1
fi

# Install dependencies
echo "Installing dependencies..."
pip3 install -r requirements.txt

# Create necessary directories
mkdir -p uploads generated_packages temp config_templates

# Set environment variables
export FLASK_APP=run.py
export FLASK_ENV=development

# Start the application
echo "Starting Flask application on http://localhost:5000"
python3 run.py